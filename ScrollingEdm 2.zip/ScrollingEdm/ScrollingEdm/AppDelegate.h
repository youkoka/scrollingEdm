//
//  AppDelegate.h
//  ScrollingEdm
//
//  Created by YehHenChia on 2017/10/26.
//  Copyright © 2017年 nil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

