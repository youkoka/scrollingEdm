//
//  ViewController.m
//  ScrollingEdm
//
//  Created by YehHenChia on 2017/10/26.
//  Copyright © 2017年 nil. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UIScrollViewDelegate>

@property (nonatomic, weak) IBOutlet UIScrollView *scrollingEdm;

@property (nonatomic, strong) NSMutableArray *imageViewAry;

@property (nonatomic) NSInteger currentPage;

@property (nonatomic) NSInteger previousPage;

@property (nonatomic) NSInteger originalPageCount;

@property (nonatomic, weak) NSTimer *timer;

/**
 更新 scroll 內容
 */
-(void) refreshScrollViewContent;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.isCarousel = YES;
    
    self.imageViewAry = [NSMutableArray array];
    
    _scrollingEdm.delegate = self;
    
    _scrollingEdm.showsVerticalScrollIndicator = NO;
    _scrollingEdm.showsHorizontalScrollIndicator = NO;
    
    [_scrollingEdm setPagingEnabled:YES];
    [_scrollingEdm setClipsToBounds:NO];
    
    self.originalPageCount = 3;
    
    self.scaleWidthPercent = 0.95;
    self.scaleHeightPercent = 0.8;
    
    self.imageNameAry = [NSArray arrayWithObjects:@"images-1", @"images-2", @"images-3", @"images-4", @"images-5", nil];
    
    _currentPage = 0;
    
}

-(void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];
    
    [self resetScrollViewContent];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) resetScrollViewContent {

    if (_imageViewAry != nil && [_imageViewAry count] > 0) {
        
        [_imageViewAry removeAllObjects];
    }
    
    NSInteger imageOrignalCount = [_imageNameAry count];
    
    NSInteger imageTotalCount = [_imageNameAry count] * 3;
    
    [_scrollingEdm setContentSize:CGSizeMake(_scrollingEdm.frame.size.width * imageTotalCount, _scrollingEdm.frame.size.height)];
    
    for (int i = 0; i != imageTotalCount; i++) {

        NSString *imageNamed = [_imageNameAry objectAtIndex:i % [_imageNameAry count]];
        
        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageNamed]];
        imageView.layer.cornerRadius = 3.0f;
        imageView.layer.masksToBounds = YES;
        
        [imageView setFrame:CGRectMake(0, 0, _scrollingEdm.frame.size.width * _scaleWidthPercent, _scrollingEdm.frame.size.height * _scaleHeightPercent)];
        
        [imageView setCenter:CGPointMake(i * _scrollingEdm.frame.size.width + _scrollingEdm.frame.size.width / 2, _scrollingEdm.frame.size.height / 2)];
        
        [_imageViewAry addObject:imageView];
        
        [_scrollingEdm addSubview:imageView];
    }
    
    if (_isCarousel) {
        
        [_scrollingEdm setContentOffset:CGPointMake(_scrollingEdm.frame.size.width * imageOrignalCount, 0) animated:NO];
        
//        [self startTimer];
    }
}

-(void) refreshScrollViewContent {
    
    for (int i = 0; i != [_imageViewAry count]; i++) {
        
        UIImageView *imageView = [_imageViewAry objectAtIndex:i];
        
        if (i == _currentPage) {
        
            [imageView setFrame:CGRectMake(0, 0, _scrollingEdm.frame.size.width, _scrollingEdm.frame.size.height)];
        }
        else {
        
            [imageView setFrame:CGRectMake(0, 0, _scrollingEdm.frame.size.width * _scaleWidthPercent, _scrollingEdm.frame.size.height * _scaleHeightPercent)];
        }
        
        [imageView setCenter:CGPointMake(i * _scrollingEdm.frame.size.width + _scrollingEdm.frame.size.width / 2, _scrollingEdm.frame.size.height / 2)];
    }
}

-(void) scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    
    [self stopTimer];
    
    _previousPage = _currentPage = floor(scrollView.contentOffset.x / scrollView.frame.size.width);
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {

    _currentPage = floor(scrollView.contentOffset.x / scrollView.frame.size.width);
    
    NSInteger imageOrignalCount = [_imageNameAry count];
    
    if (_currentPage >= 0 && _currentPage < [_imageViewAry count]) {
        
        UIImageView *currentImageView = [_imageViewAry objectAtIndex:_currentPage];
        
        CGFloat percent = (scrollView.contentOffset.x - (_currentPage * _scrollingEdm.frame.size.width)) / scrollView.frame.size.width;
        
        CGFloat diffWidthPercent = 1 - _scaleWidthPercent;
        CGFloat diffHeightPercen = 1 - _scaleHeightPercent;
        
        [currentImageView setFrame:CGRectMake(0, 0, _scrollingEdm.frame.size.width * (_scaleWidthPercent + (diffWidthPercent - diffWidthPercent * percent)), _scrollingEdm.frame.size.height * (_scaleHeightPercent + (diffHeightPercen - diffHeightPercen * percent)))];
        
        [currentImageView setCenter:CGPointMake(_currentPage * _scrollingEdm.frame.size.width + _scrollingEdm.frame.size.width / 2, _scrollingEdm.frame.size.height / 2)];

        if (_currentPage < ([_imageViewAry count] - 1)) {
            
            NSInteger page = _currentPage + 1;
            
            UIImageView *nextImageView = [_imageViewAry objectAtIndex:page];
            [nextImageView setFrame:CGRectMake(0, 0, _scrollingEdm.frame.size.width * (_scaleWidthPercent + (diffWidthPercent * percent)), _scrollingEdm.frame.size.height * (_scaleHeightPercent + (diffHeightPercen * percent)))];
            
            [nextImageView setCenter:CGPointMake(page * _scrollingEdm.frame.size.width + _scrollingEdm.frame.size.width / 2, _scrollingEdm.frame.size.height / 2)];
        }
        
        if ((_currentPage - _previousPage) <= 0) {
         
            if (_currentPage == 1) {
                
                [_scrollingEdm setContentOffset:CGPointMake(_scrollingEdm.frame.size.width * (imageOrignalCount + 2), 0) animated:NO];
                
                [self refreshScrollViewContent];
            }
        }
        else {
        
            if(_currentPage == (imageOrignalCount * 2)) {
    
                [_scrollingEdm setContentOffset:CGPointMake(_scrollingEdm.frame.size.width * imageOrignalCount, 0) animated:NO];
            
                [self refreshScrollViewContent];
            }
        }
    }
    
    _previousPage = _currentPage;
}

-(void) scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    [self refreshScrollViewContent];
    
//    [self startTimer];
}

- (void)startTimer {
    
    if (self.timer == nil) {
    
        self.timer = [NSTimer scheduledTimerWithTimeInterval:2.0f target:self selector:@selector(autoNextPage) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    }
}

-(void) autoNextPage {
    
    [_scrollingEdm setContentOffset:CGPointMake(_scrollingEdm.frame.size.width * (_currentPage + 1), 0) animated:YES];
}

- (void)stopTimer {
    
    if (self.timer != nil) {
    
        [self.timer invalidate];
        self.timer = nil;
    }
    
}
@end
