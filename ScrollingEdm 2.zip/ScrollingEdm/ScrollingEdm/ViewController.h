//
//  ViewController.h
//  ScrollingEdm
//
//  Created by YehHenChia on 2017/10/26.
//  Copyright © 2017年 nil. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSArray *imageNameAry;

/**
 寬度縮放比例
 */
@property (nonatomic) CGFloat scaleWidthPercent;

/**
 高度縮放比例
 */
@property (nonatomic) CGFloat scaleHeightPercent;

/**
 是否循環輪播
 */
@property (nonatomic) BOOL isCarousel;

@end

